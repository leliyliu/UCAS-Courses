# Divide-And-Conquer
Three problems are solved as below:

* kth-closest-point
* the-kth-number
* the-last-3-digits