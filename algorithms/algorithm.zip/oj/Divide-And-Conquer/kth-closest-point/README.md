# Kth-Closest-Point
## Problem Description
Given N points on the plane. Find the Kth closest point to the origin (0,0). (Here, the distance between two points on a plane is the Euclidean distance.)
## Input
Line 1: N K
Others: point coordinate
## Output
Line 1: Kth closest point to the origin (0,0)
## Sample Input 1
```
2 1
1 3
-2 2
```
## Sample Output 1
```
-2 2
```